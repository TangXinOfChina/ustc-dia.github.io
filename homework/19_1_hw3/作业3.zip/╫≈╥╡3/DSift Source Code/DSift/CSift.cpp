// CSift.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <string>
#include <iostream>
#include "Csiftfeature.h"
#include  <sstream> 

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	
	if (argc != 3)
	{
		cout << "Error : no input parameters! \n";
		exit(1);
	}
	else
	{
		wstring srcDir = argv[1];
		wstring stmp = argv[2];
	
		wcout << srcDir.c_str() << endl;

		int m_imgNum = 0;
		wstring siftExt = L".dsift";

		wstringstream sinstr;
		int tmpWidth = 0;
		sinstr << stmp;
		sinstr >> tmpWidth;
		
		if (tmpWidth > 640)
		{			
			siftExt = siftExt + L"_" + stmp;
		}

		ExtractFolderFeatures(srcDir, m_imgNum, siftExt, tmpWidth);
	}
	return 0;
}

